param(
    [Parameter(Mandatory=$true)][string]$RawResults,
    [Parameter(Mandatory=$true)][string]$OutputFile,
    [Parameter(Mandatory=$true)][string]$Scope,
    [Parameter(Mandatory=$true)][string]$Target,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference = "Stop"

function First($o,[string[]]$names,$default="") {
    foreach($n in $names){
        $p=$o.PSObject.Properties[$n]
        if($null -ne $p -and $null -ne $p.Value){return $p.Value}
    }
    return $default
}
function FindArray($p){
    if($p -is [Array]){return @($p)}
    foreach($n in @("findings","results","flaws")){
        $x=$p.PSObject.Properties[$n]
        if($null -ne $x){return @($x.Value)}
    }
    $e=$p.PSObject.Properties["_embedded"]
    if($null -ne $e){
        foreach($n in @("findings","results","flaws")){
            $x=$e.Value.PSObject.Properties[$n]
            if($null -ne $x){return @($x.Value)}
        }
    }
    return @()
}
function Blocking($s){
    if($null -eq $s){return $false}
    return "$s".Trim().ToLowerInvariant() -in @("very high","high","5","4")
}

$p=Get-Content -Raw $RawResults | ConvertFrom-Json
$all=@(FindArray $p)
$out=@()
foreach($f in $all){
    $sev=First $f @("severity","severity_name","severityName")
    if(-not (Blocking $sev)){continue}
    $out += [pscustomobject]@{
        issue_id=First $f @("issue_id","issueId","id","flaw_id")
        cwe=First $f @("cwe_id","cweId","cwe")
        severity=$sev
        title=First $f @("title","issue_type","name","category")
        file=First $f @("file","file_name","filename","source_file")
        line=First $f @("line","line_number","lineNumber")
        function=First $f @("function","procedure","method")
        status=First $f @("status","finding_status") "OPEN"
        description=First $f @("description","issue_details","details")
        remediation=First $f @("remediation","recommendation","fix")
        scope=$Scope
        target=$Target
        raw=$f
    }
}
[pscustomobject]@{
    generated_at=(Get-Date).ToString("o")
    scope=$Scope
    target=$Target
    raw_finding_count=$all.Count
    blocking_finding_count=$out.Count
    findings=$out
} | ConvertTo-Json -Depth 30 | Set-Content -Encoding UTF8 $OutputFile

[pscustomobject]@{
    generated_at=(Get-Date).ToString("o")
    scope=$Scope
    target=$Target
    status=$(if($out.Count -gt 0){"FAIL"}else{"PASS"})
    blocking_findings=$out.Count
    findings_file=$OutputFile
} | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory "scan-status.json")

if($out.Count -gt 0){exit 1}else{exit 0}
