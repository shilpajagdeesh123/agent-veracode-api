# Veracode HMAC request signing.
# Implements VERACODE-HMAC-SHA-256 according to Veracode's documented signing format.

function Convert-HexToBytes {
    param([Parameter(Mandatory=$true)][string]$Hex)
    if (($Hex.Length % 2) -ne 0) { throw "Hex string length must be even." }
    $bytes = New-Object byte[] ($Hex.Length / 2)
    for ($i=0; $i -lt $bytes.Length; $i++) {
        $bytes[$i] = [Convert]::ToByte($Hex.Substring($i*2, 2), 16)
    }
    return $bytes
}

function Convert-BytesToHex {
    param([Parameter(Mandatory=$true)][byte[]]$Bytes)
    return ([BitConverter]::ToString($Bytes)).Replace("-", "").ToLowerInvariant()
}

function Invoke-HmacSha256 {
    param(
        [Parameter(Mandatory=$true)][byte[]]$Key,
        [Parameter(Mandatory=$true)][byte[]]$Data
    )
    $h = New-Object System.Security.Cryptography.HMACSHA256
    try {
        $h.Key = $Key
        return $h.ComputeHash($Data)
    }
    finally {
        $h.Dispose()
    }
}

function New-VeracodeHmacAuthorization {
    param(
        [Parameter(Mandatory=$true)][string]$ApiId,
        [Parameter(Mandatory=$true)][string]$ApiKeyHex,
        [Parameter(Mandatory=$true)][string]$HostName,
        [Parameter(Mandatory=$true)][string]$RequestPathAndQuery,
        [Parameter(Mandatory=$true)][string]$Method
    )

    $timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()

    $nonceBytes = New-Object byte[] 16
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($nonceBytes) } finally { $rng.Dispose() }
    $nonceHex = Convert-BytesToHex $nonceBytes

    $secretBytes = Convert-HexToBytes $ApiKeyHex
    $kNonce = Invoke-HmacSha256 -Key $secretBytes -Data $nonceBytes
    $kDate = Invoke-HmacSha256 -Key $kNonce -Data ([Text.Encoding]::UTF8.GetBytes($timestamp))
    $kSig = Invoke-HmacSha256 -Key $kDate -Data ([Text.Encoding]::UTF8.GetBytes("vcode_request_version_1"))

    $data = "id=$ApiId&host=$HostName&url=$RequestPathAndQuery&method=$($Method.ToUpperInvariant())"
    $signature = Invoke-HmacSha256 -Key $kSig -Data ([Text.Encoding]::UTF8.GetBytes($data))
    $signatureHex = Convert-BytesToHex $signature

    return "VERACODE-HMAC-SHA-256 id=$ApiId,ts=$timestamp,nonce=$nonceHex,sig=$signatureHex"
}

function Invoke-VeracodeJsonRequest {
    param(
        [Parameter(Mandatory=$true)][ValidateSet("GET","POST","PUT","DELETE")][string]$Method,
        [Parameter(Mandatory=$true)][string]$HostName,
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ApiId,
        [Parameter(Mandatory=$true)][string]$ApiKey,
        [object]$Body = $null
    )
    $auth = New-VeracodeHmacAuthorization -ApiId $ApiId -ApiKeyHex $ApiKey -HostName $HostName -RequestPathAndQuery $Path -Method $Method
    $headers = @{
        Authorization = $auth
        Accept = "application/json"
    }
    $uri = "https://$HostName$Path"

    if ($null -eq $Body) {
        return Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers -ContentType "application/json"
    }

    $json = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 20 -Compress }
    return Invoke-RestMethod -Method $Method -Uri $uri -Headers $headers -ContentType "application/json" -Body $json
}

function Invoke-VeracodeSegmentUpload {
    param(
        [Parameter(Mandatory=$true)][string]$HostName,
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ApiId,
        [Parameter(Mandatory=$true)][string]$ApiKey,
        [Parameter(Mandatory=$true)][string]$SegmentFile
    )

    $auth = New-VeracodeHmacAuthorization -ApiId $ApiId -ApiKeyHex $ApiKey -HostName $HostName -RequestPathAndQuery $Path -Method "PUT"
    $boundary = "---------------------------" + [Guid]::NewGuid().ToString("N")
    $crlf = "`r`n"

    $fileName = [IO.Path]::GetFileName($SegmentFile)
    $prefix = "--$boundary$crlf" +
              "Content-Disposition: form-data; name=`"file`"; filename=`"$fileName`"$crlf" +
              "Content-Type: application/octet-stream$crlf$crlf"
    $suffix = "$crlf--$boundary--$crlf"

    $prefixBytes = [Text.Encoding]::UTF8.GetBytes($prefix)
    $fileBytes = [IO.File]::ReadAllBytes($SegmentFile)
    $suffixBytes = [Text.Encoding]::UTF8.GetBytes($suffix)

    $body = New-Object byte[] ($prefixBytes.Length + $fileBytes.Length + $suffixBytes.Length)
    [Array]::Copy($prefixBytes, 0, $body, 0, $prefixBytes.Length)
    [Array]::Copy($fileBytes, 0, $body, $prefixBytes.Length, $fileBytes.Length)
    [Array]::Copy($suffixBytes, 0, $body, $prefixBytes.Length + $fileBytes.Length, $suffixBytes.Length)

    $headers = @{
        Authorization = $auth
        Accept = "application/json"
    }

    $uri = "https://$HostName$Path"
    return Invoke-RestMethod -Method PUT -Uri $uri -Headers $headers `
        -ContentType "multipart/form-data; boundary=$boundary" -Body $body
}
