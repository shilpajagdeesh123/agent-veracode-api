function Split-BinaryFile {
    param(
        [Parameter(Mandatory=$true)][string]$InputFile,
        [Parameter(Mandatory=$true)][int]$SegmentCount,
        [Parameter(Mandatory=$true)][string]$OutputDirectory
    )
    if ($SegmentCount -lt 1) { throw "SegmentCount must be at least 1." }
    New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

    $stream = [IO.File]::OpenRead($InputFile)
    try {
        $length = $stream.Length
        $baseSize = [Math]::Floor($length / $SegmentCount)
        $remainder = $length % $SegmentCount
        $buffer = New-Object byte[] 1048576
        $files = @()

        for ($i=0; $i -lt $SegmentCount; $i++) {
            $segmentSize = $baseSize + $(if ($i -lt $remainder) {1} else {0})
            $segmentPath = Join-Path $OutputDirectory ("segment-{0:D4}.dat" -f $i)
            $out = [IO.File]::Create($segmentPath)
            try {
                [long]$remaining = $segmentSize
                while ($remaining -gt 0) {
                    $toRead = [Math]::Min($buffer.Length, $remaining)
                    $read = $stream.Read($buffer,0,[int]$toRead)
                    if ($read -le 0) { break }
                    $out.Write($buffer,0,$read)
                    $remaining -= $read
                }
            } finally { $out.Dispose() }
            $files += $segmentPath
        }
        return $files
    } finally { $stream.Dispose() }
}
