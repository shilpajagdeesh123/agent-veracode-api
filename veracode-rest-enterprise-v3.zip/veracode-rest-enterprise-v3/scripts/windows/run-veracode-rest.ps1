param([Parameter(Mandatory=$true)][string]$ToolHome)

$ErrorActionPreference="Stop"
$ToolHome=(Resolve-Path $ToolHome).Path
$RepoRoot=Split-Path -Parent $ToolHome

. (Join-Path $ToolHome "scripts\windows\veracode-hmac.ps1")
. (Join-Path $ToolHome "scripts\windows\split-file.ps1")

$config=Get-Content -Raw (Join-Path $ToolHome "config\scanner.json") | ConvertFrom-Json
$HostName=$config.apiHost
$PollSeconds=[int]$config.pollSeconds
$MaxMinutes=[int]$config.maxScanMinutes

$ApiId=$env:VERACODE_API_KEY_ID
if([string]::IsNullOrWhiteSpace($ApiId)){$ApiId=$env:VERACODE_API_ID}
$ApiKey=$env:VERACODE_API_KEY_SECRET
if([string]::IsNullOrWhiteSpace($ApiKey)){$ApiKey=$env:VERACODE_API_KEY}

function Fail([string]$m,[int]$c=2){Write-Host "ERROR: $m" -ForegroundColor Red; exit $c}

if([string]::IsNullOrWhiteSpace($ApiId)){Fail "VERACODE_API_KEY_ID (or VERACODE_API_ID) is not set."}
if([string]::IsNullOrWhiteSpace($ApiKey)){Fail "VERACODE_API_KEY_SECRET (or VERACODE_API_KEY) is not set."}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host " Veracode REST Enterprise Pre-Commit Scanner V3" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "1. PROJECT"
Write-Host "2. MODULE"
$choice=Read-Host "Select scan scope"
switch($choice){"1"{$Scope="PROJECT"}"2"{$Scope="MODULE"}default{Fail "Invalid scope."}}

$ignore=@(".git","node_modules","target","dist",".idea",".vscode",".angular","coverage",(Split-Path -Leaf $ToolHome))
$targets=@()

Get-ChildItem $RepoRoot -Filter pom.xml -File -Recurse -ErrorAction SilentlyContinue | % {
    $rel=$_.Directory.FullName.Substring($RepoRoot.Length).TrimStart('\')
    if(-not (($rel -split '[\\/]') | ? {$ignore -contains $_})){
        $targets += [pscustomobject]@{Path=$_.Directory.FullName;Type="maven";Marker="pom.xml"}
    }
}
Get-ChildItem $RepoRoot -Filter angular.json -File -Recurse -ErrorAction SilentlyContinue | % {
    $rel=$_.Directory.FullName.Substring($RepoRoot.Length).TrimStart('\')
    if(-not (($rel -split '[\\/]') | ? {$ignore -contains $_}) -and -not ($targets.Path -contains $_.Directory.FullName)){
        $targets += [pscustomobject]@{Path=$_.Directory.FullName;Type="angular";Marker="angular.json"}
    }
}
Get-ChildItem $RepoRoot -Filter package.json -File -Recurse -ErrorAction SilentlyContinue | % {
    $rel=$_.Directory.FullName.Substring($RepoRoot.Length).TrimStart('\')
    if(-not (($rel -split '[\\/]') | ? {$ignore -contains $_}) -and -not ($targets.Path -contains $_.Directory.FullName)){
        $targets += [pscustomobject]@{Path=$_.Directory.FullName;Type="node";Marker="package.json"}
    }
}
$targets=@($targets | Sort-Object Path -Unique)
if($targets.Count -eq 0){Fail "No Maven/Angular/Node targets found."}

for($i=0;$i -lt $targets.Count;$i++){Write-Host ("[{0}] {1} ({2})" -f ($i+1),$targets[$i].Path,$targets[$i].Type)}
[int]$n=0
if(-not [int]::TryParse((Read-Host "Select project/module"),[ref]$n)){Fail "Invalid selection."}
if($n -lt 1 -or $n -gt $targets.Count){Fail "Selection out of range."}

$Target=$targets[$n-1]
$TargetPath=$Target.Path
$TargetName=Split-Path -Leaf $TargetPath
$TargetType=$Target.Type

$date=Get-Date -Format "yyyy-MM-dd"
$base=Join-Path $RepoRoot (".github\Output\{0}\{1}" -f $TargetName,$date)
$OutputDir=$base
if(Test-Path (Join-Path $OutputDir "results.json")){
    $OutputDir=Join-Path $base (Get-Date -Format "HHmmss")
}
New-Item -ItemType Directory -Force $OutputDir | Out-Null
$PackageDir=Join-Path $OutputDir "package"
New-Item -ItemType Directory -Force $PackageDir | Out-Null

$agentDir=Join-Path $RepoRoot ".github\agents"
New-Item -ItemType Directory -Force $agentDir | Out-Null
Copy-Item -Force (Join-Path $ToolHome "templates\.github\agents\veracode-remediation-agent.md") `
    (Join-Path $agentDir "veracode-remediation-agent.md")

Write-Host ""
Write-Host "Scope : $Scope"
Write-Host "Target: $TargetPath"
Write-Host "Output: $OutputDir"

if($TargetType -eq "maven"){
    Push-Location $TargetPath
    try{
        if(Test-Path (Join-Path $TargetPath "mvnw.cmd")){
            & (Join-Path $TargetPath "mvnw.cmd") clean package -DskipTests
        } elseif(Get-Command mvn -ErrorAction SilentlyContinue){
            & mvn clean package -DskipTests
        } else {Fail "Maven or mvnw.cmd is required."}
        if($LASTEXITCODE -ne 0){Fail "Maven build failed." 3}
    } finally {Pop-Location}

    $artifact=Get-ChildItem (Join-Path $TargetPath "target") -File -ErrorAction SilentlyContinue |
      ? {$_.Extension -in @(".jar",".war",".ear") -and $_.Name -notmatch "sources|javadoc|original"} |
      Sort-Object Length -Descending | Select-Object -First 1
    if(-not $artifact){Fail "No JAR/WAR/EAR found." 3}
    $ArtifactPath=$artifact.FullName
} else {
    $ArtifactPath=Join-Path $PackageDir ("{0}-{1}.zip" -f $TargetName,$Scope)
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $ToolHome "scripts\windows\package-js.ps1") `
       -SourceDir $TargetPath -OutputZip $ArtifactPath
    if($LASTEXITCODE -ne 0){Fail "JS/Angular packaging failed." 3}
}

$fi=Get-Item $ArtifactPath
$hash=(Get-FileHash -Algorithm SHA256 $ArtifactPath).Hash.ToLowerInvariant()

$createBody=[ordered]@{
    binary_name=$fi.Name
    binary_size=[long]$fi.Length
    binary_hash=$hash
    project_name=$TargetName
    project_uri=""
    dev_stage=$config.developmentStage
}

Write-Host "Configuring Pipeline Scan REST request..."
$create=Invoke-VeracodeJsonRequest -Method POST -HostName $HostName -Path "/pipeline_scan/v1/scans" `
    -ApiId $ApiId -ApiKey $ApiKey -Body $createBody

$scanId=$create.scan_id
$segments=[int]$create.binary_segments_expected
if([string]::IsNullOrWhiteSpace($scanId)){Fail "Veracode did not return scan_id." 4}
if($segments -lt 1){Fail "Veracode returned invalid binary_segments_expected." 4}

$segmentDir=Join-Path $PackageDir "segments"
$segmentFiles=@(Split-BinaryFile -InputFile $ArtifactPath -SegmentCount $segments -OutputDirectory $segmentDir)

Write-Host ("Uploading {0} segment(s)..." -f $segments)
for($i=0;$i -lt $segmentFiles.Count;$i++){
    Write-Host ("  segment {0}/{1}" -f ($i+1),$segmentFiles.Count)
    $path="/pipeline_scan/v1/scans/$scanId/segments/$i"
    $null=Invoke-VeracodeSegmentUpload -HostName $HostName -Path $path -ApiId $ApiId -ApiKey $ApiKey -SegmentFile $segmentFiles[$i]
}

Write-Host "Starting scan..."
$null=Invoke-VeracodeJsonRequest -Method PUT -HostName $HostName -Path "/pipeline_scan/v1/scans/$scanId" `
    -ApiId $ApiId -ApiKey $ApiKey -Body @{scan_status="STARTED"}

$deadline=(Get-Date).AddMinutes($MaxMinutes)
$details=$null
do{
    Start-Sleep -Seconds $PollSeconds
    $details=Invoke-VeracodeJsonRequest -Method GET -HostName $HostName -Path "/pipeline_scan/v1/scans/$scanId" `
        -ApiId $ApiId -ApiKey $ApiKey
    $status="$($details.scan_status)"
    Write-Host ("Scan status: {0}" -f $status)
    if($status -eq "SUCCESS"){break}
    if($status -in @("ERROR","FAILED","CANCELLED","CANCELED")){Fail "Veracode scan ended with status $status. $($details.message)" 5}
} while((Get-Date) -lt $deadline)

if("$($details.scan_status)" -ne "SUCCESS"){Fail "Scan timed out after $MaxMinutes minutes." 5}

Write-Host "Retrieving findings..."
$findings=Invoke-VeracodeJsonRequest -Method GET -HostName $HostName -Path "/pipeline_scan/v1/scans/$scanId/findings" `
    -ApiId $ApiId -ApiKey $ApiKey

$rawFile=Join-Path $OutputDir "results.json"
$findings | ConvertTo-Json -Depth 50 | Set-Content -Encoding UTF8 $rawFile

[pscustomobject]@{
    scan_id=$scanId
    scope=$Scope
    target=$TargetName
    target_path=$TargetPath
    artifact=$ArtifactPath
    binary_hash=$hash
    binary_size=$fi.Length
    scan_status=$details.scan_status
    created=$create.created
    completed=(Get-Date).ToString("o")
} | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 (Join-Path $OutputDir "scan-metadata.json")

$normalized=Join-Path $OutputDir "veracode-findings.json"
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $ToolHome "scripts\windows\normalize-findings.ps1") `
    -RawResults $rawFile -OutputFile $normalized -Scope $Scope -Target $TargetName -OutputDirectory $OutputDir
$gate=$LASTEXITCODE

Remove-Item -Recurse -Force $segmentDir -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Reports:"
Write-Host "  $OutputDir"
if($gate -eq 0){
    Write-Host "SECURITY VALIDATION: PASS" -ForegroundColor Green
    exit 0
}
Write-Host "SECURITY VALIDATION: FAIL" -ForegroundColor Yellow
Write-Host "Use Copilot agent: veracode-remediation-agent"
Write-Host "Prompt: Remediate the latest Veracode findings for $TargetName under .github/Output."
exit 1
