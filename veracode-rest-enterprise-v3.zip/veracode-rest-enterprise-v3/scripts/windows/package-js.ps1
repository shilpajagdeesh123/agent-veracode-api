param(
    [Parameter(Mandatory=$true)][string]$SourceDir,
    [Parameter(Mandatory=$true)][string]$OutputZip
)
$ErrorActionPreference = "Stop"
$SourceDir = (Resolve-Path $SourceDir).Path
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputZip) | Out-Null
if (Test-Path $OutputZip) { Remove-Item -Force $OutputZip }

$excludeDirs = @(".git","node_modules","dist","coverage",".angular",".cache","target",".github")
$allowedExt = @(".asp",".cjs",".css",".ehtml",".es",".es6",".handlebars",".hbs",".hjs",".htm",".html",
                ".js",".jsx",".json",".jsp",".map",".mjs",".mustache",".php",".ts",".tsx",".vue",".xhtml",
                ".yaml",".yml")
$important = @("package.json","package-lock.json","angular.json","tsconfig.json","tsconfig.app.json",
               "nx.json","workspace.json","project.json")

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($OutputZip,[System.IO.Compression.ZipArchiveMode]::Create)
try {
    Get-ChildItem $SourceDir -File -Recurse | ForEach-Object {
        $rel = $_.FullName.Substring($SourceDir.Length).TrimStart('\','/')
        $parts = $rel -split '[\\/]'
        if ($parts | Where-Object { $excludeDirs -contains $_ }) { return }
        if (($allowedExt -contains $_.Extension.ToLowerInvariant()) -or ($important -contains $_.Name)) {
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $zip,$_.FullName,$rel.Replace('\','/'),
                [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    }
} finally { $zip.Dispose() }
