# Veracode REST Enterprise Pre-Commit Scanner V3

This package uses the **Veracode Pipeline Scan REST API directly**.

It does **not** require:
- `pipeline-scan.jar`
- Python
- a Python installation
- admin rights for Python

Windows execution uses PowerShell plus your Veracode HMAC REST API credentials.

## Output layout

All scan evidence is created at repository level:

```text
<repository>/
└── .github/
    ├── agents/
    │   └── veracode-remediation-agent.md
    └── Output/
        └── <project-or-module-name>/
            └── YYYY-MM-DD/
                ├── results.json
                ├── veracode-findings.json
                ├── scan-status.json
                ├── scan-metadata.json
                ├── remediation-report.md
                └── package/
```

If another scan is run for the same target on the same date, a timestamp directory is created under the date folder so previous evidence is retained.

## Flow

Developer changes code
→ `run-veracode.bat`
→ choose PROJECT or MODULE
→ choose target
→ build/package
→ configure Pipeline Scan through REST API
→ upload artifact segments
→ start scan
→ poll scan status
→ retrieve findings
→ write `.github/Output/<target>/<date>/...`
→ Copilot remediation
→ re-scan
→ PASS
→ commit

## Credentials

Set your HMAC credentials as environment variables.

PowerShell:

```powershell
$env:VERACODE_API_KEY_ID="YOUR_API_ID"
$env:VERACODE_API_KEY_SECRET="YOUR_SECRET"
```

Command Prompt:

```bat
set VERACODE_API_KEY_ID=YOUR_API_ID
set VERACODE_API_KEY_SECRET=YOUR_SECRET
```

Legacy aliases are also accepted by this package:

```text
VERACODE_API_ID
VERACODE_API_KEY
```

Do not commit credentials.

## Run

```bat
run-veracode.bat
```

See `docs/WINDOWS-EXECUTION.md`.
