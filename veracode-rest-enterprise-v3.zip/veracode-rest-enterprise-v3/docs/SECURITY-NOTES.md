# Security Notes

- API secret is read from environment variables only.
- The secret key is used to derive an HMAC signature and is not sent directly.
- Never write credentials into JSON reports or Copilot prompts.
- Ensure workstation time is synchronized; Veracode HMAC authentication is timestamp-sensitive.
- Restrict `.github/Output` retention according to your organization's source and vulnerability-data policy.
- The package defaults to blocking High and Very High findings locally.
