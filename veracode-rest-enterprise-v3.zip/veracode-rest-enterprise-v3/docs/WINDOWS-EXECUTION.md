# Windows Execution

## Folder placement

```text
C:\work\my-repository\
├── customer-service\
├── payment-service\
├── customer-ui\
└── veracode-rest-enterprise-v3\
```

## Prerequisites

- Network HTTPS access to your Veracode REST API regional host.
- HMAC API credentials with Pipeline Scan permissions.
- Maven/Maven Wrapper for Java builds.
- PowerShell available on Windows.

No Pipeline Scan JAR and no Python are required.

## Credentials

PowerShell:

```powershell
$env:VERACODE_API_KEY_ID="..."
$env:VERACODE_API_KEY_SECRET="..."
```

or Command Prompt:

```bat
set VERACODE_API_KEY_ID=...
set VERACODE_API_KEY_SECRET=...
```

## Execute

```bat
cd C:\work\my-repository\veracode-rest-enterprise-v3
run-veracode.bat
```

Choose PROJECT or MODULE, then the discovered target.

## REST lifecycle used

1. Compute artifact SHA-256 and size.
2. POST `/pipeline_scan/v1/scans`.
3. Read `scan_id` and `binary_segments_expected`.
4. Split artifact into the required number of segments.
5. PUT each segment to `/pipeline_scan/v1/scans/{scan_id}/segments/{n}`.
6. PUT `{"scan_status":"STARTED"}` to the scan.
7. GET scan details until `SUCCESS`.
8. GET `/pipeline_scan/v1/scans/{scan_id}/findings`.
9. Generate normalized reports.
10. Run Copilot remediation and re-scan.

## Output

Example:

```text
.github/
└── Output/
    └── customer-service/
        └── 2026-07-24/
            ├── results.json
            ├── veracode-findings.json
            ├── scan-status.json
            ├── scan-metadata.json
            └── package/
```

Repeated same-day scans are preserved in timestamp folders.
