@echo off
setlocal EnableExtensions
set "TOOL_HOME=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TOOL_HOME%scripts\windows\run-veracode-rest.ps1" -ToolHome "%TOOL_HOME%"
exit /b %ERRORLEVEL%
