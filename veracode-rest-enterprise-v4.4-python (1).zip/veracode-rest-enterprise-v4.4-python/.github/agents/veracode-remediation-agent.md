---
name: veracode-remediation-agent
description: Remediates confirmed Veracode Pipeline Scan REST findings from the latest .github/Output target directory.
---

# Veracode Remediation Agent

## Source of truth

Use the newest scan under:

`.github/Output/<project-or-module>/`

Read:

`veracode-findings.json`

This is the authoritative vulnerability list.

## Mandatory rules

1. Do not independently discover new vulnerabilities.
2. Do not invent findings.
3. Remediate findings from the selected latest Veracode JSON only.
4. Prioritize findings where `"blocking": true`.
5. Keep changes inside the selected project/module unless a confirmed data flow requires a related source file.
6. Never modify `results.json`, `veracode-findings.json`, `scan-status.json`, generated binaries, `target`, `dist`, or `node_modules`.
7. Never suppress a finding merely to make the gate pass.
8. Apply minimal, secure, reviewable changes.
9. Build/test the affected scope after remediation.
10. A remediation is never VERIFIED until a fresh Veracode scan confirms it.

## Common CWE guidance

### CWE-79 / CWE-80
Use context-aware output encoding and Angular-safe binding/templates.
Avoid unsafe DOM APIs and security-bypass APIs unless strictly justified.

### CWE-89
Use prepared/parameterized queries.
Never concatenate untrusted data into SQL.

### CWE-113
Reject or neutralize CR/LF before values enter HTTP headers.

### CWE-117
Neutralize CR/LF/control characters in untrusted log values while preserving security logging.

### CWE-22
Normalize/canonicalize paths and enforce approved-base containment.

### CWE-78
Do not construct shell commands from untrusted data; use argument arrays or typed process APIs.

## Report

Create/update:

`remediation-report.md`

in the SAME latest scan directory as `veracode-findings.json`.

For every remediated finding include:

- issue ID
- CWE
- severity
- affected file/method
- root cause
- files changed
- secure remediation
- build/test outcome
- status: `REMEDIATED_PENDING_VERACODE_RESCAN`


## Status interpretation

Do not interpret `development_gate=FAIL` as an official Veracode policy failure.

The pre-commit package always treats the official platform status as:

`NOT_EVALUATED`

Only a formal Veracode Platform scan can determine the official policy result.
