@echo off
setlocal EnableExtensions

set "TOOL_HOME=%~dp0"
set "PYTHON_EXE=%TOOL_HOME%runtime\python\python.exe"

if not exist "%PYTHON_EXE%" (
    echo.
    echo Bundled Python runtime is not initialized.
    echo Running local no-admin runtime setup...
    echo.
    call "%TOOL_HOME%setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        exit /b 2
    )
)

"%PYTHON_EXE%" "%TOOL_HOME%app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
exit /b %ERRORLEVEL%
