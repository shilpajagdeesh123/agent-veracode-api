

## V4.5 — results.json-driven Copilot remediation

V4.5 adds a GitHub Copilot project skill:

```text
.github/
├── agents/
│   └── veracode-remediation-agent.md
└── skills/
    └── veracode-remediation/
        └── SKILL.md
```

The remediation workflow now treats the raw Pipeline Scan `results.json` as the
authoritative input. Normalized JSON/CSV outputs remain available for reporting,
but are not the primary remediation source.

Recommended Copilot prompt:

```text
Remediate the latest Veracode findings for customer-service using results.json.
```


## V5 — Mainframe + secret-file credentials

V5 adds:

- automatic mainframe/COBOL discovery and source packaging;
- HMAC credentials loaded from `config/veracode-secrets.json`;
- helper `create-secret-file.bat`;
- no need to set credential environment variables;
- PROJECT / MODULE / EXISTING VERACODE PACKAGE modes retained;
- JSON + CSV output retained;
- raw `results.json` remains the authoritative Copilot remediation input.
