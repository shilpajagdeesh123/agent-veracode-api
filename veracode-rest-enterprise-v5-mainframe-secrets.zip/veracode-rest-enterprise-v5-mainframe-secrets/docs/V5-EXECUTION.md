# V5 Windows execution

1. Initialize Python once:

```bat
setup-runtime.bat
```

2. Create HMAC secret file:

```bat
create-secret-file.bat
```

3. Edit:

```text
config\veracode-secrets.json
```

4. Run:

```bat
run-veracode.bat
```

5. Choose:

```text
1. PROJECT
2. MODULE
3. EXISTING VERACODE PACKAGE
```

Detected technology types include:

```text
maven
angular
node
mainframe
```

Reports remain under:

```text
.github\Output\<target>\<date>\
```

Copilot remediation still uses the latest raw:

```text
results.json
```

with:

```text
.github\agents\veracode-remediation-agent.md
.github\skills\veracode-remediation\SKILL.md
```
