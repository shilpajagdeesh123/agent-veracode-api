# Existing Veracode Package Mode

V4.4 adds:

```text
1. PROJECT
2. MODULE
3. EXISTING VERACODE PACKAGE
```

Use option 3 when you already have the package used for a Veracode Platform/UI scan
and want the closest possible Pipeline Scan comparison.

Example package:

```text
C:\VeracodePackages\project.zip
  customer-api.jar
  customer-service.jar
  customer-common.jar
```

## Execution

```bat
run-veracode.bat
```

Choose:

```text
3
```

Enter:

```text
C:\VeracodePackages\project.zip
```

Optionally provide a report/project name. Press Enter to use `project`.

V4.4 does NOT:
- run Maven;
- rebuild the JARs;
- unzip/re-zip the package;
- add/remove files;
- rename the submitted artifact;
- modify the package.

It computes SHA-256 and size against the exact selected file and submits that same
file through Pipeline Scan REST.

A copy is retained under the scan `package` directory for local evidence, but the
original selected file is the one submitted.

## Important comparison limitation

Using the exact UI package removes packaging differences as a major source of
variation. It does not guarantee an exact UI result because Pipeline Scan and the
Veracode Platform differ in policy evaluation, flaw history/matching, mitigations,
SCA, and other Platform processing.

`scan-status.json` therefore continues to report:

```text
pipeline_scan_status
development_gate
official_veracode_policy_status = NOT_EVALUATED
```
