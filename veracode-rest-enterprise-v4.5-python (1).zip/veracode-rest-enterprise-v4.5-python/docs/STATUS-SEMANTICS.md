# Status semantics — V4.3

V4.3 intentionally separates development scanning from official Veracode policy evaluation.

## Pipeline Scan Status

Indicates whether the Pipeline Scan REST operation itself completed successfully.

Example:

```text
PIPELINE SCAN STATUS: SUCCESS
```

This means Veracode completed the development Pipeline Scan.

## Development Security Gate

This is the local pre-commit rule configured by this package.

Default blocking severities:

```text
Very High
High
```

Example:

```text
DEVELOPMENT SECURITY GATE: FAIL
```

This means one or more development Pipeline Scan findings matched the configured
local blocking severities.

It does NOT mean that the official Veracode UI policy is failing.

## Official Veracode Policy Status

For this package:

```text
OFFICIAL VERACODE POLICY STATUS: NOT_EVALUATED
```

The pre-commit Pipeline Scan package deliberately does not claim to reproduce or
evaluate the official Veracode Platform policy result.

The official policy state is determined later by your formal Upload & Scan /
Platform workflow.

## Output files

Each scan creates:

```text
results.json
results.csv
veracode-findings.json
veracode-findings.csv
scan-status.json
scan-metadata.json
development-scan-summary.txt
```

`scan-status.json` includes:

```json
{
  "pipeline_scan_status": "SUCCESS",
  "development_gate": "FAIL",
  "official_veracode_policy_status": "NOT_EVALUATED"
}
```
