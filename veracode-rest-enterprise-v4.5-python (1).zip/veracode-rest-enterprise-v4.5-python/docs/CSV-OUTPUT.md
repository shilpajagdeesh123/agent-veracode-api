# CSV output

V4.2 creates CSV output automatically after retrieving Veracode findings.

For every successful scan:

```text
.github\Output\<project-or-module>\<YYYY-MM-DD>\
    results.json
    results.csv
    veracode-findings.json
    veracode-findings.csv
    scan-status.json
    scan-metadata.json
```

`results.json` preserves the raw Veracode REST response.

`results.csv` is a flattened CSV representation of the normalized findings and is convenient for Excel, reporting, filtering, and sharing.

`veracode-findings.json` remains the primary structured input for the Copilot remediation agent.

`veracode-findings.csv` contains the same normalized findings in CSV form.

CSV columns:

```text
issue_id
cwe
severity
title
file
line
function
status
blocking
scope
target
description
remediation
```

The CSV uses UTF-8 with BOM so it opens cleanly in Microsoft Excel on Windows.
