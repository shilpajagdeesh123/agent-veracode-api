# Bundled/local Python runtime security

V4 uses Python's official Windows embeddable distribution.

Pinned runtime:
- Python 3.13.14
- Windows x86-64 embeddable package
- Source: python.org
- SHA-256:
  `90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907`

The runtime is extracted locally only:
- no admin installation;
- no registry changes;
- no PATH changes;
- no pip packages;
- scanner uses Python standard library only.

`setup-runtime.bat` verifies SHA-256 before extraction.
