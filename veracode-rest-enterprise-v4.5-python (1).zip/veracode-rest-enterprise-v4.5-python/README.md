

## V4.5 — results.json-driven Copilot remediation

V4.5 adds a GitHub Copilot project skill:

```text
.github/
├── agents/
│   └── veracode-remediation-agent.md
└── skills/
    └── veracode-remediation/
        └── SKILL.md
```

The remediation workflow now treats the raw Pipeline Scan `results.json` as the
authoritative input. Normalized JSON/CSV outputs remain available for reporting,
but are not the primary remediation source.

Recommended Copilot prompt:

```text
Remediate the latest Veracode findings for customer-service using results.json.
```
