This directory is populated by setup-runtime.bat.

V4 pins the official Python 3.13.14 Windows 64-bit embeddable runtime.

The binary runtime itself could not be embedded into the generated ChatGPT artifact because this environment blocks exporting Windows executable/runtime binaries.

On first run, setup-runtime.bat downloads it from python.org, verifies the official SHA-256, and extracts it here without administrator rights.

For offline enterprise use, pre-stage:
runtime\download\python-3.13.14-embed-amd64.zip
