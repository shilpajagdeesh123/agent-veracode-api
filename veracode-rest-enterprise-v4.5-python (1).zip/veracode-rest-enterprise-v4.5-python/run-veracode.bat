@echo off
setlocal EnableExtensions

rem Normalize the package folder. %~dp0 ends with "\" and can be mis-parsed
rem when passed as the final quoted argument to python.exe.
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

if not exist "%PYTHON_EXE%" (
    echo.
    echo Bundled Python runtime is not initialized.
    echo Running local no-admin runtime setup...
    echo.
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        exit /b 2
    )
)

if not exist "%TOOL_HOME%\config\scanner.json" (
    echo.
    echo ERROR: scanner.json was not found:
    echo   %TOOL_HOME%\config\scanner.json
    exit /b 3
)

echo.
echo Tool home:
echo   %TOOL_HOME%
echo.

"%PYTHON_EXE%" "%TOOL_HOME%\app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
exit /b %ERRORLEVEL%
